public class BeaconID {


    //variables
    int beaconID;
    double edgeX;
    double edgeY;
    double edgeZ;
    int edgeNode;
    double gamma;
    double bias;


    public int getBeaconID() {
        return beaconID;
    }

    public void setBeaconID(int beaconID) {
        this.beaconID = beaconID;
    }

    public double getEdgeX() {
        return edgeX;
    }

    public void setEdgeX(double edgeX) {
        this.edgeX = edgeX;
    }

    public double getEdgeY() {
        return edgeY;
    }

    public void setEdgeY(double edgeY) {
        this.edgeY = edgeY;
    }

    public double getEdgeZ() {
        return edgeZ;
    }

    public void setEdgeZ(double edgeZ) {
        this.edgeZ = edgeZ;
    }

    public int getEdgeNode() {
        return edgeNode;
    }

    public void setEdgeNode(int edgeNode) {
        this.edgeNode = edgeNode;
    }

    public double getGamma() {
        return gamma;
    }

    public void setGamma(double gamma) {
        this.gamma = gamma;
    }

    public double getBias() {
        return bias;
    }

    public void setBias(double bias) {
        this.bias = bias;
    }

    public BeaconID(int beaconID, int edgeNode, double gamma, double bias, double edgeX, double edgeY, double edgeZ){
        this.beaconID = beaconID;
        this.edgeNode = edgeNode;
        this.gamma = gamma;
        this.bias = bias;
        this.edgeX = edgeX;
        this.edgeY = edgeY;
        this.edgeZ = edgeZ;
    }


}
