public class Compare {

    double length;
    int id;

    public Compare( int id, double length){
        this.id = id;
        this.length = length;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public String toString(){
        return "id : " + getId() + " distance : " + length;
    }
}
