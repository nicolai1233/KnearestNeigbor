import java.util.Random;

public class Driver {


    public static void main(String[] args) {
        NearestNeighbor nn = new NearestNeighbor();
        nn.calculateKNearest();
    }
}
