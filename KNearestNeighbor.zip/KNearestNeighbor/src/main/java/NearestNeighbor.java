import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.SocketException;
import java.util.*;

public class NearestNeighbor {

    double random = new Random().nextDouble();

    private final ArrayList<BeaconID> arrlist = new ArrayList();

    public NearestNeighbor(){
        readFile();
    }
    public void readFile(){
        String splitLine = ",";
        String line = "";
        try{
            BufferedReader bf = new BufferedReader(new FileReader("C:\\Users\\robert\\Downloads\\KNearestNeighbor\\edges.csv"));
            while((line = bf.readLine()) != null){
                String[] stringArr = line.split(splitLine);
                arrlist.add(new BeaconID(Integer.parseInt(stringArr[0]),Integer.parseInt(stringArr[1]),Double.parseDouble(stringArr[2]),
                        Double.parseDouble(stringArr[3]),Double.parseDouble(stringArr[4]),Double.parseDouble(stringArr[5]),Double.parseDouble(stringArr[6])));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public double distanceBetween(double x1, double y1, double z1,double x2, double y2, double z2){
        double term1 = (x2 - x1) * (x2 - x1);
        double term2 = (y2 - y1) * (y2 - y1);
        double term3 = (z2 - z1) * (z2 - z1);
        double sum = term1 + term2 + term3;
        String convertedSum = Double.toString(sum);
        double convertedToDoubleSum = Double.parseDouble(convertedSum);
        double distance = Math.abs (Math.sqrt (convertedToDoubleSum ) );
        String convertedDistance = Double.toString(distance);
        return Float.parseFloat(convertedDistance);
    }

    public int findK(){
       return (int) (Math.sqrt(arrlist.size()) / 2);
    }
    public BeaconID getRandomPoint(){
        return new BeaconID(0,0,0,0, 10 + (random * (35 - 10)),10 + (random * (55 - 10)) , 1.6);
    }
    public int calculateKNearest(){
        int occurence = 0;
        int k = findK();
        BeaconID id = getRandomPoint();
        ArrayList<Compare> sortList = new ArrayList<>();

        for (BeaconID beaconID : arrlist) {
            sortList.add(new Compare(beaconID.getBeaconID(),distanceBetween(id.edgeX, id.edgeY, id.edgeZ, beaconID.getEdgeX(), beaconID.getEdgeY(), beaconID.getEdgeZ())));

        }

        Collections.sort(sortList, new SortBy());
        for(Compare com : sortList){
            System.out.println(com.toString());
        }
        /**
         *
         */
        int max_count = 1, res = sortList.get(0).getId();
        int curr_count = 0;
        for (int i = 1; i <k; i++) {
            if(sortList.get(i).getId() == sortList.get(i-1).getId()){
                curr_count++;
            }else{
                if(curr_count>max_count){
                    max_count = curr_count;
                    res = sortList.get(i-1).getId();
                }
                curr_count = 1;
            }
        }
        if(curr_count>max_count){
            max_count = curr_count;
            res = sortList.get(k-1).getId();
        }
        System.out.println("Beacon ID  is " + res);
        return res;
    }
}
class SortBy implements Comparator<Compare> {
    @Override
    public int compare(Compare o1, Compare o2) {
       return Double.compare(o1.getLength(),o2.getLength());
    }
}
